<?php

namespace App\Http\Controllers;

use App\FlightBooking;
use Illuminate\Http\Request;

class FlightBookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FlightBooking  $flightBooking
     * @return \Illuminate\Http\Response
     */
    public function show(FlightBooking $flightBooking)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FlightBooking  $flightBooking
     * @return \Illuminate\Http\Response
     */
    public function edit(FlightBooking $flightBooking)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FlightBooking  $flightBooking
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FlightBooking $flightBooking)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FlightBooking  $flightBooking
     * @return \Illuminate\Http\Response
     */
    public function destroy(FlightBooking $flightBooking)
    {
        //
    }
}
