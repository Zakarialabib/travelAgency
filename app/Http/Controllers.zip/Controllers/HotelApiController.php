<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HotelApiController extends Controller
{
    //
}
